# AirAware — Urban Air Quality Assistant

A responsive, browser-based urban air quality dashboard. It looks up a city, retrieves hourly air-quality estimates, displays a US AQI reading, pollutant concentrations, a 24-hour outlook, and practical health guidance.

## Features
- Search for a city or town worldwide
- Optional browser geolocation (only after the user clicks **Use my location** and grants permission)
- Current/latest available hourly US AQI and PM2.5-based fallback calculation
- PM2.5, PM10, ozone, nitrogen dioxide, sulphur dioxide and carbon monoxide readings
- 24-hour AQI outlook chart
- Health guidance based on AQI category
- Responsive desktop and mobile layout

## Run locally
No build step or API key is needed.

1. Extract the ZIP.
2. Open a terminal in this folder.
3. Start a local server:
   - Python: `python -m http.server 8000`
   - Or VS Code: use the Live Server extension.
4. Visit `http://localhost:8000`.

Opening `index.html` directly may work, but a local server is recommended.

## Data source
- Open-Meteo Geocoding API: `https://geocoding-api.open-meteo.com`
- Open-Meteo Air Quality API: `https://air-quality-api.open-meteo.com`

The dashboard requests `us_aqi` and hourly pollutant values. Open-Meteo data is modelled hourly data, not a certified street-level regulatory monitor. Coverage and freshness vary by location.

## AQI interpretation
The interface uses the US EPA AQI category ranges:
- 0–50 Good
- 51–100 Moderate
- 101–150 Unhealthy for Sensitive Groups
- 151–200 Unhealthy
- 201–300 Very Unhealthy
- 301–500 Hazardous

## Important limitations
- This is an educational prototype, not a medical device or emergency alert service.
- Health tips are general information, not a diagnosis or substitute for local public-health advice.
- The 24-hour outlook uses hourly forecast values returned by the data provider.
- A production deployment should add error monitoring, accessibility testing, caching, and source attribution consistent with provider terms.

## Suggested next improvements
1. Add user-configurable pollution alert thresholds.
2. Save favorite cities in local storage.
3. Add a map with multiple monitoring locations.
4. Add a backend for scheduled alerts and historical analytics.
5. Add a formal evaluation section comparing forecasts with local station observations.
