const $ = (id) => document.getElementById(id);
const pollutantMeta = [
  ["PM2.5","Fine particles","pm2_5"],["PM10","Coarse particles","pm10"],
  ["O₃","Ozone","ozone"],["NO₂","Nitrogen dioxide","nitrogen_dioxide"],
  ["SO₂","Sulphur dioxide","sulphur_dioxide"],["CO","Carbon monoxide","carbon_monoxide"]
];
let currentForecast = [];
function aqiCategory(aqi){
  if(aqi<=50)return {name:"Good",color:"#54c68c",advice:"Air quality is satisfactory. Enjoy outdoor activities as usual.",tip:"It's a good day to get outside.",tipText:"Enjoy a walk, cycle or outdoor workout. Keep checking conditions as they can change through the day."};
  if(aqi<=100)return {name:"Moderate",color:"#d6c84d",advice:"Air quality is acceptable. Unusually sensitive people may notice mild effects.",tip:"A little awareness goes a long way.",tipText:"Most people can continue normal activities. If you are unusually sensitive to pollution, consider shorter or less intense outdoor exercise."};
  if(aqi<=150)return {name:"Unhealthy for sensitive groups",color:"#e99a4c",advice:"Sensitive groups should reduce prolonged or heavy outdoor exertion.",tip:"Take it a little easier outdoors.",tipText:"Children, older adults and people with heart or lung conditions should reduce prolonged outdoor exertion. Consider moving exercise indoors."};
  if(aqi<=200)return {name:"Unhealthy",color:"#d95f5b",advice:"Everyone may begin to experience health effects; sensitive groups may experience more serious effects.",tip:"Consider limiting outdoor time.",tipText:"Reduce prolonged or heavy outdoor activity. Keep windows closed when practical and consider a well-fitted particulate respirator if you must be outside."};
  if(aqi<=300)return {name:"Very unhealthy",color:"#9566a7",advice:"Health alert: everyone may experience more serious health effects.",tip:"Protect your breathing.",tipText:"Avoid outdoor exertion. Stay indoors with doors and windows closed when practical, and use a suitable air purifier if available."};
  return {name:"Hazardous",color:"#7e3445",advice:"Health emergency conditions. Avoid outdoor activity and follow local public-health advice.",tip:"Stay indoors if possible.",tipText:"Avoid going outdoors. Keep windows and doors closed, use indoor air filtration if available, and follow local authority guidance."};
}
function pm25ToAQI(c){
  const bands=[[0,12,0,50],[12.1,35.4,51,100],[35.5,55.4,101,150],[55.5,150.4,151,200],[150.5,250.4,201,300],[250.5,500.4,301,500]];
  const v=Math.max(0,Math.min(500.4,c));
  for(const [lo,hi,alo,ahi] of bands)if(v>=lo&&v<=hi)return Math.round((ahi-alo)/(hi-lo)*(v-lo)+alo);
  return 0;
}
function showToast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600)}
function latestIndex(hourly,key){const a=hourly?.[key];return a?.length?a.length-1:-1}
function fmt(v){return Number.isFinite(v)?(v<10?v.toFixed(1):Math.round(v).toString()):"—"}
async function geocode(city){
  const url=`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=en&format=json`;
  const r=await fetch(url);if(!r.ok)throw Error("City search failed");const j=await r.json();
  if(!j.results?.length)throw Error("Couldn't find that place. Try another city name.");
  return j.results[0];
}
async function loadAir(lat,lon,name,country){
  $("updated").textContent="Fetching latest available readings…";
  const url=`https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${lon}&hourly=pm10,pm2_5,carbon_monoxide,nitrogen_dioxide,sulphur_dioxide,ozone,us_aqi&forecast_days=2&timezone=auto`;
  const r=await fetch(url);if(!r.ok)throw Error("Air quality service is temporarily unavailable");const data=await r.json();
  const h=data.hourly;if(!h?.time?.length)throw Error("No air quality readings available for this location.");
  let idx=h.time.findLastIndex(t=>new Date(t)<=new Date());if(idx<0)idx=0;
  let aqi=Number.isFinite(h.us_aqi?.[idx])?Math.round(h.us_aqi[idx]):pm25ToAQI(h.pm2_5?.[idx]??0);
  const cat=aqiCategory(aqi);
  $("placeName").textContent=`${name}, ${country||"—"}`;$("aqiValue").textContent=aqi;$("aqiStatus").textContent=cat.name;
  $("aqiAdvice").textContent=cat.advice;$("aqiValue").style.color=cat.color;
  $("scaleMarker").style.left=`${Math.min(99,aqi/500*100)}%`;
  $("readingTime").textContent=(h.time[idx]||"").replace("T"," ")+" local";
  $("updated").textContent="Updated just now · Modelled hourly data";
  $("tipTitle").textContent=cat.tip;$("tipText").textContent=cat.tipText;
  $("pollutants").innerHTML=pollutantMeta.map(([label,desc,key])=>`<article class="pollutant"><span class="poll-icon">◌</span><span class="poll-name">${label}</span><strong>${fmt(h[key]?.[idx])}</strong><small>${desc}</small></article>`).join("");
  currentForecast=[];
  for(let i=idx;i<Math.min(idx+24,h.time.length);i++){
    const value=Number.isFinite(h.us_aqi?.[i])?Math.round(h.us_aqi[i]):pm25ToAQI(h.pm2_5?.[i]??0);
    currentForecast.push({time:h.time[i],value});
  }
  drawChart();drawHealth(cat.name,aqi);
}
function drawChart(){
  const c=$("chart");if(!currentForecast.length){c.innerHTML='<div class="chart-empty">Forecast unavailable</div>';return}
  const max=Math.max(100,...currentForecast.map(x=>x.value));
  c.innerHTML=currentForecast.filter((_,i)=>i%2===0).map(x=>{
    const height=Math.max(4,x.value/max*100);
    return `<div class="bar-wrap" title="${x.time.replace("T"," ")} · AQI ${x.value}"><div class="bar" style="height:${height}%"></div><span class="bar-label">${x.time.slice(11,16)}</span></div>`;
  }).join("");
  const avg=Math.round(currentForecast.reduce((s,x)=>s+x.value,0)/currentForecast.length);
  $("forecastSummary").textContent=`24h average: ${avg} AQI`;
}
function drawHealth(level,aqi){
  const items=aqi<=50?[
    ["✓","Outdoor activity","Air quality is good for outdoor exercise and daily activities."],
    ["↗","Keep moving","A walk or cycle is a good way to enjoy the day."],
    ["◷","Stay informed","Check again later because conditions can change."]
  ]:aqi<=100?[
    ["♡","Sensitive individuals","People unusually sensitive to pollution may wish to reduce intense outdoor activity."],
    ["↗","Outdoor exercise","Most people can continue normal activities."],
    ["◷","Check later","Recheck the AQI before long outdoor plans."]
  ]:aqi<=150?[
    ["!","Sensitive groups","Children, older adults and people with heart or lung disease should limit prolonged outdoor exertion."],
    ["⌂","Plan activities","Move strenuous exercise indoors if possible."],
    ["◷","Watch symptoms","If you feel unwell, move to cleaner air and seek medical advice when needed."]
  ]:[
    ["!","Reduce exposure","Limit outdoor exertion; at higher levels, avoid outdoor activity."],
    ["⌂","Improve indoor air","Close windows when practical and use a suitable air purifier if available."],
    ["♡","Take extra care","Follow local public-health guidance, especially for respiratory or heart conditions."]
  ];
  $("healthList").innerHTML=items.map(([sym,title,desc])=>`<div class="health-item"><div class="health-symbol">${sym}</div><div><strong>${title}</strong><p>${desc}</p></div></div>`).join("");
}
async function searchCity(){
  const city=$("cityInput").value.trim();if(!city)return showToast("Enter a city or town name.");
  $("searchBtn").disabled=true;$("searchBtn").textContent="…";
  try{const p=await geocode(city);await loadAir(p.latitude,p.longitude,p.name,p.country);}
  catch(e){showToast(e.message);$("updated").textContent="Unable to refresh data."}
  finally{$("searchBtn").disabled=false;$("searchBtn").textContent="Search"}
}
$("searchBtn").addEventListener("click",searchCity);
$("cityInput").addEventListener("keydown",e=>{if(e.key==="Enter")searchCity()});
$("locateBtn").addEventListener("click",()=>{
  if(!navigator.geolocation)return showToast("Location is not supported by this browser.");
  $("updated").textContent="Requesting your location…";
  navigator.geolocation.getCurrentPosition(async pos=>{
    try{
      const {latitude,longitude}=pos.coords;
      const r=await fetch(`https://geocoding-api.open-meteo.com/v1/reverse?latitude=${latitude}&longitude=${longitude}&language=en&format=json`);
      const j=await r.json();const p=j.results?.[0]||{};
      $("cityInput").value=p.name||"My location";await loadAir(latitude,longitude,p.name||"Your location",p.country||"");
    }catch(e){showToast("Couldn't load data for your location.");}
  },()=>{showToast("Location permission was not granted.");$("updated").textContent="Search for a city instead."},{timeout:10000});
});
$("forecastNav").addEventListener("click",()=>$("forecast").scrollIntoView({behavior:"smooth"}));
$("healthNav").addEventListener("click",()=>$("health").scrollIntoView({behavior:"smooth"}));
searchCity();
